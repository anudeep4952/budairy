/*
class ResponseRecordModel{
  String recordId;
  String userId;
  String year;
  String month;
  String date;
  int amount;
  String need;

  ResponseRecordModel({this.recordId,this.userId, this.year, this.month, this.date,
    this.amount, this.need});

  factory ResponseRecordModel.fromJson(Map<String, dynamic> json){
    return ResponseRecordModel(
      recordId: json['recordId'],
      userId:json['userId'],
      year:json['year'],
      month:json['month'],
      date:json['date'],
      amount:json['amount'],
      need:json['need'],
    );
  }

  Map<String,dynamic> toMap(){
    final Map<String,dynamic> map = new Map<String, dynamic>();
    map['recordId']=recordId;
    map['userId']=userId;
    map['year']=year;
    map['month']=month;
    map['date']=date;
    map['amount']=amount;
    map['need']=need;
    return map;
  }


}*/
