/*
class RecordModel{
  String userId="abcd1234";
  String year;
  String month;
  String date;
  int amount;
  String need;

  RecordModel({this.userId, this.year, this.month, this.date,
      this.amount, this.need});

  factory RecordModel.fromJson(Map<String, dynamic> json){
    return RecordModel(
      userId:json['userId'],
      year:json['year'],
      month:json['month'],
      date:json['date'],
      amount:json['amount'],
      need:json['need'],
    );
  }

  Map<String,dynamic> toMap(){
    final Map<String,dynamic> map = new Map<String, dynamic>();
    map['userId']=userId;
    map['year']=year;
    map['month']=month;
    map['date']=date;
    map['amount']=amount;
    map['need']=need;
    return map;
  }


}*/
